package com.pi.backend.repository;

import com.pi.backend.model.Espacio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EspacioRepository extends JpaRepository<Espacio, Long> {}
