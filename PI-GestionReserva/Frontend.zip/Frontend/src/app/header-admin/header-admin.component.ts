import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router'; // AÑADIR

@Component({
  selector: 'app-header-admin',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header-admin.component.html',
  styleUrls: ['./header-admin.component.css']
})
export class HeaderAdminComponent {
  @Input() nombreUsuario: string = '';

  mostrarMenu: boolean = false;
  pantallaPequena: boolean = false;

  constructor(public authService: AuthService, private router: Router) {} // AÑADIR Router

  cerrarSesion(): void {
    this.authService.logout();
    this.router.navigate(['/login']); // CAMBIAR ESTO
  }
}
