import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

export interface Profesor {
  idProfesor: number;
  usuario: string;
  nombre: string; // Nombre completo del profesor
  clave: string;
  roles: { nombre_rol?: string }[]; // Array de roles con el campo nombre_rol
}


@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = 'http://localhost:8085/api/auth/login';
  private rol: string = '';
  private usuario: string = '';
  private nombreCompleto: string = '';

  constructor(private http: HttpClient) {}

login(usuario: string, clave: string): Observable<Profesor> {
  return this.http.post<Profesor>(this.apiUrl, { usuario, clave }).pipe(
    tap((profesor) => {
      this.usuario = profesor.usuario;
      this.nombreCompleto = profesor.nombre;

      // Cambiado para leer 'nombre_rol' en vez de 'nombre' en roles
      if (profesor.roles && profesor.roles.length > 0 && profesor.roles[0].nombre_rol) {
        this.rol = profesor.roles[0].nombre_rol.toLowerCase();
      } else {
        this.rol = ''; // o asignar un rol por defecto
      }

      localStorage.setItem('usuario', this.usuario);
      localStorage.setItem('nombreCompleto', this.nombreCompleto);
      localStorage.setItem('rol', this.rol);
    })
  );
}







  setUsuario(usuario: string): void {
    this.usuario = usuario;
    localStorage.setItem('usuario', usuario);
  }

  setRol(rol: string): void {
    this.rol = rol;
    localStorage.setItem('rol', rol);
  }

  getRol(): string {
    return this.rol || localStorage.getItem('rol') || '';
  }

  getUsuario(): string {
    return this.usuario || localStorage.getItem('usuario') || '';
  }

  getNombreCompleto(): string {
    return this.nombreCompleto || localStorage.getItem('nombreCompleto') || '';
  }

  logout(): void {
    this.usuario = '';
    this.nombreCompleto = '';
    this.rol = '';
    localStorage.removeItem('usuario');
    localStorage.removeItem('nombreCompleto');
    localStorage.removeItem('rol');
  }
}
