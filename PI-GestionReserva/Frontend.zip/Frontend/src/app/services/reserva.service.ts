import { Injectable } from '@angular/core';
import { Observable, forkJoin } from 'rxjs';
import { HttpBaseService } from './http-base.service';

@Injectable({
  providedIn: 'root'
})
export class ReservaService {
  private apiUrl = 'http://ocalhost:8085';

  constructor(private http: HttpBaseService) {}

  // ESPACIOS
  guardarReservaEspacio(reserva: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/api/reservaEspacio/crear`, reserva);
  }

  getReservasEspacio(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/api/reservaEspacio`);
  }

  getReservasHistoricoPorProfesor(id: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/api/reservaEspacio/historico/${id}`);
  }

  eliminarReservaEspacio(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/api/reservaEspacio/eliminar/${id}`);
  }

  // RECURSOS
  guardarReservaRecurso(reserva: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/api/reservaRecurso/crear`, reserva);
  }

  getReservasRecurso(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/api/reservaRecurso`);
  }

  getRecursos(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/api/recursos`);
  }

  // COMBINADO
  getHistorialCompleto(): Observable<[any[], any[]]> {
    return forkJoin([
      this.getReservasEspacio(),
      this.getReservasRecurso()
    ]);
  }
}
