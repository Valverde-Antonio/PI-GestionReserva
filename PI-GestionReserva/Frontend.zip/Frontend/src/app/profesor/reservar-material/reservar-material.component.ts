import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RecursoService } from '../../services/recurso.service';
import { ReservaService } from '../../services/reserva.service';

@Component({
  selector: 'app-reservar-material',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reservar-material.component.html',
  styleUrls: ['./reservar-material.component.css']
})
export class ReservarMaterialComponent implements OnInit {
  recursos: any[] = [];
  recursoSeleccionado: any = null;
  fechaSeleccionada: string = '';
  cantidad: number = 1;
  mensaje: string = '';

  turnos: string[] = [
    '08:00 - 09:00',
    '09:00 - 10:00',
    '10:00 - 11:00',
    '11:00 - 11:30',
    '11:30 - 12:30',
    '12:30 - 13:30',
    '13:30 - 14:30'
  ];

  reservas: { [key: string]: number } = {};

  constructor(
    private recursoService: RecursoService,
    private reservaService: ReservaService
  ) {}

  ngOnInit(): void {
    this.cargarRecursos();
  }

  cargarRecursos(): void {
    this.recursoService.getRecursos().subscribe({
      next: data => {
        this.recursos = data;
        if (this.recursos.length > 0) {
          this.recursoSeleccionado = this.recursos[0].id;
        }
      },
      error: err => console.error('Error al cargar recursos', err)
    });
  }

  cargarReservas(): void {
    this.reservaService.getReservasRecurso().subscribe({
      next: data => {
        // Puedes procesar aquí si necesitas evitar duplicadas o mostrar reservas actuales
        console.log('Reservas cargadas:', data);
      },
      error: err => console.error('Error al cargar reservas', err)
    });
  }

  reservar(turno: string): void {
    const clave = `${this.fechaSeleccionada}_${turno}`;
    if (this.reservas[clave]) {
      alert('Ya hay una reserva para ese turno.');
      return;
    }

    const reserva = {
      fecha: this.fechaSeleccionada,
      tramoHorario: turno,
      idRecurso: this.recursoSeleccionado,
      idProfesor: 1, // Ajusta esto según tu lógica de usuario
      cantidad: this.cantidad
    };

    this.reservaService.guardarReservaRecurso(reserva).subscribe({
      next: () => {
        this.mensaje = 'Reserva realizada con éxito.';
        this.reservas[clave] = reserva.cantidad;
      },
      error: err => {
        console.error('Error al guardar reserva:', err);
        this.mensaje = 'Error al realizar la reserva.';
      }
    });
  }

  isReservado(turno: string): boolean {
    const clave = `${this.fechaSeleccionada}_${turno}`;
    return !!this.reservas[clave];
  }

  cantidadReservada(turno: string): number {
    const clave = `${this.fechaSeleccionada}_${turno}`;
    return this.reservas[clave] || 0;
  }
}
