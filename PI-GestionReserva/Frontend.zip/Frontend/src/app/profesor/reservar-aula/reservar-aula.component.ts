import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReservaService } from '../../services/reserva.service';

@Component({
  selector: 'app-reservar-espacio',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reservar-aula.component.html', // ✅ Corregido aquí
  styleUrls: ['./reservar-aula.component.css']   // ✅ Corregido aquí
})
export class ReservarEspacioComponent implements OnInit {
  fechaSeleccionada: string = '';
  aulaSeleccionada: string = '';
  aulas: string[] = ['Aula 1', 'Aula 2', 'Aula 3'];
  mensaje: string = '';

  turnos = [
    { hora: '08:00 - 09:00', reservado: false },
    { hora: '09:00 - 10:00', reservado: false },
    { hora: '10:00 - 11:00', reservado: false },
    { hora: '11:00 - 11:30', reservado: false },
    { hora: '11:30 - 12:30', reservado: false },
    { hora: '12:30 - 13:30', reservado: false },
    { hora: '13:30 - 14:30', reservado: false }
  ];

  constructor(private reservaService: ReservaService) {}

  ngOnInit(): void {}

  reservar(hora: string): void {
    const turno = this.turnos.find(t => t.hora === hora);
    if (!turno || turno.reservado) return;

    const confirmacion = confirm(`¿Deseas reservar el aula ${this.aulaSeleccionada} el ${this.fechaSeleccionada} de ${hora}?`);
    if (confirmacion) {
      const reserva = {
        fecha: this.fechaSeleccionada,
        tramoHorario: hora,
        espacio: { nombre: this.aulaSeleccionada },
        profesor: { id: 1 } // ⚠️ Ajustar según el usuario autenticado
      };

      this.reservaService.guardarReservaEspacio(reserva).subscribe({
        next: () => {
          turno.reservado = true;
          this.mensaje = 'Reserva de aula realizada con éxito';
          console.log(this.mensaje);
        },
        error: err => {
          console.error('Error al realizar la reserva:', err);
        }
      });
    }
  }

  isReservado(turno: any): boolean {
    return turno.reservado;
  }

  motivo(turno: any): string {
    return 'Ocupado';
  }
}
